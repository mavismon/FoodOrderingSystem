<?php
$host = "localhost";
$user = "root";
$passwd = "";
$database = "foodorder";
$conn = mysqli_connect($host, $user, $passwd, $database) or die("Could not connect to the database.");

if (isset($_POST['productid'])) {
    $customer = $_POST['customer'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $remarks = $_POST['remarks'];

    // Prepare the INSERT statement
    $insertPurchaseStmt = $conn->prepare("INSERT INTO purchase (customer, date_purchase, address, phone, email, remarks) VALUES (?, NOW(), ?, ?, ?, ?)");
    $insertPurchaseStmt->bind_param("sssss", $customer, $address, $phone, $email, $remarks);
    $insertPurchaseStmt->execute();

    $purchaseId = $conn->insert_id;
    $total = 0;

    foreach ($_POST['productid'] as $product) {
        $productInfo = explode("||", $product);
        $productId = $productInfo[0];
        $iteration = $productInfo[1];

        $sql = "SELECT * FROM product WHERE productid = '$productId'";
        $query = $conn->query($sql);
        $row = $query->fetch_array();

        if (isset($_POST['quantity_' . $iteration])) {
            $quantity = $_POST['quantity_' . $iteration];
            $subTotal = $row['price'] * $quantity;
            $total += $subTotal;

            // Prepare the INSERT statement
            $insertDetailStmt = $conn->prepare("INSERT INTO purchase_detail (purchaseid, productid, quantity, subtotal) VALUES (?, ?, ?, ?)");
            $insertDetailStmt->bind_param("iiid", $purchaseId, $productId, $quantity, $subTotal);
            $insertDetailStmt->execute();
        }
    }

    // Update the total in the purchase table
    $updateTotalStmt = $conn->prepare("UPDATE purchase SET total = ? WHERE purchaseid = ?");
    $updateTotalStmt->bind_param("di", $total, $purchaseId);
    $updateTotalStmt->execute();

    session_start();
    $_SESSION['sess_pid'] = $purchaseId;
    $_SESSION['total'] = $total;
    $_SESSION['order_time'] = time();

    header('location: ordersuccess.php');
} else {
    ?>
    <script>
        window.alert('Please select a product');
        window.location.href = 'order.php';
    </script>
    <?php
}
?>
